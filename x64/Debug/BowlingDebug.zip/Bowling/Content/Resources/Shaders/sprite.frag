#version 460 core

in vec2 TexCoords;
out vec4 color;

uniform sampler2D image;

void main()
{    
    color = texture(image, TexCoords);

    if(color.a < 0.1) discard;
}